-- Pedidos para impressão automática na térmica Bluetooth do balcão.
-- Reaproveita create_order (regra de horário) e admin_check_password (auth do gestor).

create table if not exists public.pedidos (
  id          bigint generated always as identity primary key,
  dia         date        not null,
  numero      int         not null,
  cliente     text        not null,
  modalidade  text        not null,
  itens       jsonb       not null,
  adicionais  jsonb       not null default '[]'::jsonb,
  observacoes text,
  total       numeric(10,2) not null,
  ip_hash     text        not null,
  created_at  timestamptz not null default now(),
  printed_at  timestamptz,
  unique (dia, numero)
);

create index if not exists pedidos_pendentes_idx on public.pedidos (id) where printed_at is null;
create index if not exists pedidos_ip_idx        on public.pedidos (ip_hash, created_at);

-- RLS sem policy = nenhum acesso direto. Tudo passa pelas RPCs abaixo.
alter table public.pedidos enable row level security;
revoke all on public.pedidos from anon, authenticated;

-- ---------------------------------------------------------------------------
-- Cliente: registra o pedido (substitui a chamada direta a create_order)
-- ---------------------------------------------------------------------------
create or replace function public.place_order(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_cliente    text  := left(btrim(coalesce(p_payload->>'customerName', '')), 60);
  v_modalidade text  := left(btrim(coalesce(p_payload->>'orderType', '')), 40);
  v_obs        text  := nullif(left(btrim(coalesce(p_payload->>'notes', '')), 300), '');
  v_itens      jsonb := coalesce(p_payload->'items', '[]'::jsonb);
  v_adicionais jsonb := coalesce(p_payload->'addons', '[]'::jsonb);
  v_dia        date  := (now() at time zone 'America/Sao_Paulo')::date;
  v_total      numeric;
  v_ip         text;
  v_numero     int;
  v_id         bigint;
begin
  -- Regra de horário existente: create_order lança STORE_CLOSED se fechado.
  if to_regprocedure('public.create_order(jsonb)') is not null then
    perform public.create_order(p_payload);
  elsif to_regprocedure('public.create_order(json)') is not null then
    perform public.create_order(p_payload::json);
  else
    raise exception 'create_order ausente';
  end if;

  if pg_column_size(p_payload) > 8192 then
    raise exception 'PAYLOAD_TOO_LARGE';
  end if;
  if char_length(v_cliente) < 2 then
    raise exception 'INVALID_NAME';
  end if;
  if v_modalidade = '' then
    raise exception 'INVALID_ORDER_TYPE';
  end if;
  if jsonb_typeof(v_itens) <> 'array'
     or jsonb_array_length(v_itens) = 0
     or jsonb_array_length(v_itens) > 30 then
    raise exception 'INVALID_ITEMS';
  end if;
  if jsonb_typeof(v_adicionais) <> 'array' or jsonb_array_length(v_adicionais) > 10 then
    raise exception 'INVALID_ADDONS';
  end if;

  v_total := round((p_payload->>'total')::numeric, 2);
  if v_total is null or v_total <= 0 or v_total > 2000 then
    raise exception 'INVALID_TOTAL';
  end if;

  -- Normaliza itens/adicionais: só os campos que o cupom usa, com limites.
  select jsonb_agg(jsonb_build_object(
           'name',  left(coalesce(e->>'name', ''), 60),
           'qty',   least(greatest(coalesce((e->>'qty')::int, 1), 1), 50),
           'price', left(coalesce(e->>'price', ''), 12)))
    into v_itens
    from jsonb_array_elements(v_itens) e;

  select coalesce(jsonb_agg(jsonb_build_object(
           'name',  left(coalesce(e->>'name', ''), 60),
           'qty',   least(greatest(coalesce((e->>'qty')::int, 1), 1), 50),
           'price', left(coalesce(e->>'price', ''), 12))), '[]'::jsonb)
    into v_adicionais
    from jsonb_array_elements(v_adicionais) e;

  -- Rate limit por IP (hash, nunca em claro): 5 pedidos / 10 min.
  v_ip := md5(coalesce(split_part(
            current_setting('request.headers', true)::json->>'x-forwarded-for', ',', 1), ''));
  if (select count(*) from pedidos
       where ip_hash = v_ip and created_at > now() - interval '10 minutes') >= 5 then
    raise exception 'RATE_LIMITED';
  end if;

  -- Numeração diária sequencial (#1, #2...) sem corrida.
  perform pg_advisory_xact_lock(hashtext('pedidos_numero'));
  select coalesce(max(numero), 0) + 1 into v_numero from pedidos where dia = v_dia;

  insert into pedidos (dia, numero, cliente, modalidade, itens, adicionais, observacoes, total, ip_hash)
  values (v_dia, v_numero, v_cliente, v_modalidade, v_itens, v_adicionais, v_obs, v_total, v_ip)
  returning id into v_id;

  -- Aviso instantâneo pro celular da impressora (só o id; dados exigem senha).
  begin
    perform realtime.send(jsonb_build_object('id', v_id), 'novo', 'pedidos-novos', false);
  exception when others then
    null; -- polling da página da impressora cobre
  end;

  return jsonb_build_object('id', v_id, 'numero', v_numero);
end;
$$;

-- ---------------------------------------------------------------------------
-- Gestor: pedidos aguardando impressão
-- ---------------------------------------------------------------------------
create or replace function public.admin_pedidos_pendentes(p_password text)
returns table (
  id bigint, numero int, cliente text, modalidade text, itens jsonb,
  adicionais jsonb, observacoes text, total numeric, created_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
#variable_conflict use_column
begin
  if not public.admin_check_password(p_password) then
    raise exception 'UNAUTHORIZED';
  end if;

  return query
    select p.id, p.numero, p.cliente, p.modalidade, p.itens,
           p.adicionais, p.observacoes, p.total, p.created_at
      from pedidos p
     where p.printed_at is null
       and p.created_at > now() - interval '12 hours'
     order by p.id
     limit 20;
end;
$$;

-- ---------------------------------------------------------------------------
-- Gestor: confirma impressão
-- ---------------------------------------------------------------------------
create or replace function public.admin_marcar_impresso(p_password text, p_ids bigint[])
returns int
language plpgsql
security definer
set search_path = public
as $$
declare
  v_count int;
begin
  if not public.admin_check_password(p_password) then
    raise exception 'UNAUTHORIZED';
  end if;

  update pedidos set printed_at = now()
   where id = any(p_ids) and printed_at is null;
  get diagnostics v_count = row_count;
  return v_count;
end;
$$;

revoke all on function public.place_order(jsonb)                   from public;
revoke all on function public.admin_pedidos_pendentes(text)        from public;
revoke all on function public.admin_marcar_impresso(text, bigint[]) from public;
grant execute on function public.place_order(jsonb)                   to anon, authenticated;
grant execute on function public.admin_pedidos_pendentes(text)        to anon, authenticated;
grant execute on function public.admin_marcar_impresso(text, bigint[]) to anon, authenticated;
